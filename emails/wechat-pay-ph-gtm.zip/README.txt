HitPay EDM - WeChat Pay PH GTM
