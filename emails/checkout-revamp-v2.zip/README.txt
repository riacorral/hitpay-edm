HitPay EDM - Checkout Revamp (V2)
=================================
Subject : Remember your checkout page? We just made it a whole lot better.

CONTENTS
--------
index.mjml      -- Source MJML (upload this ZIP to Loops)
index.html      -- Local preview (open in browser after extracting)
img/            -- All images (Loops hosts these on its CDN automatically)

HOW TO UPLOAD TO LOOPS
----------------------
1. Extract this ZIP and open index.html in a browser to preview.
2. In Loops: Campaigns > New Campaign > Upload MJML > select this ZIP file.
   Loops will rewrite all img/ paths to its CDN at send time.

NOTES
-----
- [First Name] is a Loops merge field placeholder.
- {unsubscribe_link} is replaced by Loops at send time.
